<?php get_header(); ?>
<?php if(have_posts()): ?>
        <?php while(have_posts()): the_post(); ?>
        
         <?php
                $merchImage = get_field('merch_image_main');
                $merchImageOptional1 = get_field('merch_image_optional_1');
                $merchImageOptional2 = get_field('merch_image_optional_2');
                $merchTitle = get_the_title();
                $merchPrice = get_field('merch_item_price');
                $merchSpecifications = get_field('merch_item_specifications');
                $merchDescription = get_field('merch_item_description');
                $merchCategory = get_field('merch_item_category');

                        if ($merchCategory) {
                            if (is_object($merchCategory)) {
                            $categoryLabel = $merchCategory->name;
                                                    }
                        }
            ?>

                        <section class="merchItemSection">
                            <section class="merchItemSectionTop">
                                <div class="merchItemImageArea">
                                    <div class="merchSideImages">
                                        <?php 
                                            $images = [$merchImageOptional1, $merchImageOptional2];

                                            foreach ($images as $image) {
                                                if ($image) {
                                                    echo '<img src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['alt']) . '">';
                                                }
                                            }
                                        ?>
                                    </div>
                                    <div class="merchMainImage"><img src="<?php echo esc_url($merchImage['url'])?>" alt="<?php echo esc_attr($merchImage['alt']); ?>"></div>
                                </div>
                                <div class="merchItemTextArea">
                                    <h2 aria-labbelledby="ProductTitle productDescription" id="ProductTitle" tabindex="0"><?php echo esc_html($merchTitle); ?></h2>
                                    <h3><?php echo esc_html($categoryLabel); ?></h3>
                                    <p>kr <?php echo esc_html($merchPrice); ?>,-</p>
                                    <div class="sizesArea">

                                    </div>
                                    <div class="merchItemTextAreaBottom">
                                        <form class="buyForm" method="post" action="">
                                            <label for="purchase-amount" class="sr-only">Purchase amount</label>
                                            <input id="purchase-amount" type="number" name="quantity" value="1" min="1">
                                            <button type="submit" class="buyButton">Læg i kurv</button>
                                        </form>
                                    </div>
                                </div>
                            </section>
                            <section class="merchItemSectionBottom">
                                <h3>Produkt beskrivelse</h3>
                                <div class="merchItemSpecifications">
                                    <?php echo $merchSpecifications; ?>
                                </div>
                                <div id="productDescription" class="merchItemDescription">
                                    <?php echo $merchDescription; ?>
                                </div>
                            </section>
                            <section class="otherItemsSection">
                              <h3>Andre produkter</h3>
                                <?php
                                    $args = array(
                                    'post_type'      => 'merch-item',
                                    'posts_per_page' => 3,
                                    'lang' => pll_current_language(),
                                    );

                                    $loop = new WP_Query($args);

                                    if ($loop->have_posts()) :
                                    while ($loop->have_posts()) : $loop->the_post();
                                        
                                        $merchImage = get_field('merch_image_main');
                                        $merchTitle = get_the_title();
                                        $merchPrice = get_field('merch_item_price');
                                        $merchCategory = get_field('merch_item_category');

                                                if ($merchCategory) {
                                                    if (is_object($merchCategory)) {
                                                    $categoryLabel = $merchCategory->name;
                                                                            }
                                                }
                                ?>
                            <a href="<?php the_permalink(); ?>">
                                
                                <div class="merchCard">
                                <div class="merchCardImageContainer">
                                    <img src="<?php echo esc_url($merchImage['url'])?>" alt="<?php echo esc_attr($merchImage['alt']); ?>">
                                </div>
                                <span><?php echo esc_html($categoryLabel); ?></span>
                                <h4><?php echo esc_html($merchTitle); ?></h4>
                                <div class="merchPriceContainer"><p>kr <?php echo esc_html($merchPrice); ?>,-</p></div>

                        
                                </div>
                            </a>
                                <?php
                                    endwhile;
                                    endif;
                                    wp_reset_postdata();
                                ?>
                            </section>
                        </section>

                                            



        <?php endwhile; ?>
    <?php endif; ?>

<?php get_footer(); ?>